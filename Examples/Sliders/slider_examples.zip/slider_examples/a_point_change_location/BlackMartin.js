var bm = {
    "type": "FeatureCollection",
    "features": [
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.678,-14.6788 ]
     },
     "properties": {
     "date":"10/6/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.0799652,-14.40680926 ]
     },
     "properties": {
     "date":"10/7/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.3451527,-14.00900946 ]
     },
     "properties": {
     "date":"10/8/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.3973839,-13.59842035 ]
     },
     "properties": {
     "date":"10/9/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.296356,-13.19015151 ]
     },
     "properties": {
     "date":"10/10/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.160956,-12.81916532 ]
     },
     "properties": {
     "date":"10/11/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.0508085,-12.556129 ]
     },
     "properties": {
     "date":"10/12/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.964286,-12.41336073 ]
     },
     "properties": {
     "date":"10/13/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.896648,-12.30016806 ]
     },
     "properties": {
     "date":"10/14/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.9331667,-12.23002216 ]
     },
     "properties": {
     "date":"10/15/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.1081654,-12.18391339 ]
     },
     "properties": {
     "date":"10/16/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.4515557,-12.2177863 ]
     },
     "properties": {
     "date":"10/17/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.1599934,-12.36741953 ]
     },
     "properties": {
     "date":"10/18/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.7513527,-12.50585904 ]
     },
     "properties": {
     "date":"10/19/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.6169134,-12.50757464 ]
     },
     "properties": {
     "date":"10/20/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.2896728,-12.44405199 ]
     },
     "properties": {
     "date":"10/21/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.9414684,-12.42068975 ]
     },
     "properties": {
     "date":"10/22/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.7648786,-12.42441959 ]
     },
     "properties": {
     "date":"10/23/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.9673314,-12.51317822 ]
     },
     "properties": {
     "date":"10/24/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.3435957,-12.70889388 ]
     },
     "properties": {
     "date":"10/25/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.8058137,-12.97794665 ]
     },
     "properties": {
     "date":"10/26/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.1802576,-13.13135656 ]
     },
     "properties": {
     "date":"10/27/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.231683,-13.34110768 ]
     },
     "properties": {
     "date":"10/28/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.9294605,-13.63119984 ]
     },
     "properties": {
     "date":"10/29/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.3499806,-13.80632122 ]
     },
     "properties": {
     "date":"10/30/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.5053988,-13.68701023 ]
     },
     "properties": {
     "date":"10/31/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.789095,-13.53302584 ]
     },
     "properties": {
     "date":"11/1/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.7039275,-13.55528418 ]
     },
     "properties": {
     "date":"11/2/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.1428755,-13.65784182 ]
     },
     "properties": {
     "date":"11/3/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.7957571,-13.79509084 ]
     },
     "properties": {
     "date":"11/4/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.6806665,-13.89039536 ]
     },
     "properties": {
     "date":"11/5/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.2612618,-13.91732669 ]
     },
     "properties": {
     "date":"11/6/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.6995561,-13.8336362 ]
     },
     "properties": {
     "date":"11/7/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.2594513,-13.74161277 ]
     },
     "properties": {
     "date":"11/8/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.3220552,-13.74539667 ]
     },
     "properties": {
     "date":"11/9/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.6462132,-13.84261469 ]
     },
     "properties": {
     "date":"11/10/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.0196327,-13.95338414 ]
     },
     "properties": {
     "date":"11/11/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.4412438,-14.10749138 ]
     },
     "properties": {
     "date":"11/12/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.8048619,-14.22730971 ]
     },
     "properties": {
     "date":"11/13/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.6973612,-14.38865211 ]
     },
     "properties": {
     "date":"11/14/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.3676027,-14.58866923 ]
     },
     "properties": {
     "date":"11/15/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.8242501,-14.73817795 ]
     },
     "properties": {
     "date":"11/16/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.1511508,-14.761161 ]
     },
     "properties": {
     "date":"11/17/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.1931939,-14.81185127 ]
     },
     "properties": {
     "date":"11/18/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.5969916,-14.90029664 ]
     },
     "properties": {
     "date":"11/19/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.5286091,-15.02619107 ]
     },
     "properties": {
     "date":"11/20/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.0501134,-15.13384865 ]
     },
     "properties": {
     "date":"11/21/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.3259096,-15.17356855 ]
     },
     "properties": {
     "date":"11/22/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.5075221,-15.10570331 ]
     },
     "properties": {
     "date":"11/23/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.6384277,-14.98015578 ]
     },
     "properties": {
     "date":"11/24/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.6193647,-14.77701151 ]
     },
     "properties": {
     "date":"11/25/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.5486302,-14.56881713 ]
     },
     "properties": {
     "date":"11/26/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.3104196,-14.33732515 ]
     },
     "properties": {
     "date":"11/27/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.8623773,-14.14487105 ]
     },
     "properties": {
     "date":"11/28/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.1239309,-13.93330026 ]
     },
     "properties": {
     "date":"11/29/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.9722805,-13.59151696 ]
     },
     "properties": {
     "date":"11/30/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 144.840188,-13.29999553 ]
     },
     "properties": {
     "date":"12/1/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 144.4126207,-13.09292079 ]
     },
     "properties": {
     "date":"12/2/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 144.6030093,-13.00022462 ]
     },
     "properties": {
     "date":"12/3/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 144.8102488,-13.00901359 ]
     },
     "properties": {
     "date":"12/4/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 144.8456432,-13.09198159 ]
     },
     "properties": {
     "date":"12/5/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 145.3411718,-13.17465085 ]
     },
     "properties": {
     "date":"12/6/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.0353407,-13.33490444 ]
     },
     "properties": {
     "date":"12/7/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.5944288,-13.58546441 ]
     },
     "properties": {
     "date":"12/8/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.872084,-13.88629606 ]
     },
     "properties": {
     "date":"12/9/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.8803066,-14.1307284 ]
     },
     "properties": {
     "date":"12/10/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 146.9042265,-14.35572707 ]
     },
     "properties": {
     "date":"12/11/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 147.4759482,-14.53298233 ]
     },
     "properties": {
     "date":"12/12/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 148.4906462,-14.72559134 ]
     },
     "properties": {
     "date":"12/13/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 149.4464646,-14.98387611 ]
     },
     "properties": {
     "date":"12/14/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 149.9678359,-15.3687379 ]
     },
     "properties": {
     "date":"12/15/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 150.2302837,-15.85755634 ]
     },
     "properties": {
     "date":"12/16/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 150.9416278,-16.27567269 ]
     },
     "properties": {
     "date":"12/17/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 152.7620378,-16.65322851 ]
     },
     "properties": {
     "date":"12/18/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 154.961802,-17.14434937 ]
     },
     "properties": {
     "date":"12/19/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 156.7127385,-17.64297409 ]
     },
     "properties": {
     "date":"12/20/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.2907608,-17.95751334 ]
     },
     "properties": {
     "date":"12/21/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.3656166,-18.1360959 ]
     },
     "properties": {
     "date":"12/22/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.3799464,-18.13157488 ]
     },
     "properties": {
     "date":"12/23/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.5011971,-18.13162691 ]
     },
     "properties": {
     "date":"12/24/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.733971,-18.24687179 ]
     },
     "properties": {
     "date":"12/25/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.8976279,-18.41116532 ]
     },
     "properties": {
     "date":"12/26/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 157.9845011,-18.53567324 ]
     },
     "properties": {
     "date":"12/27/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 158.0651631,-18.54391017 ]
     },
     "properties": {
     "date":"12/28/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 158.2612077,-18.43544254 ]
     },
     "properties": {
     "date":"12/29/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 158.8336889,-18.28733621 ]
     },
     "properties": {
     "date":"12/30/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 160.2213203,-18.1009675 ]
     },
     "properties": {
     "date":"12/31/2011",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 161.9654182,-17.98758384 ]
     },
     "properties": {
     "date":"1/1/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 163.8564493,-17.92223216 ]
     },
     "properties": {
     "date":"1/2/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 165.6589252,-17.92483455 ]
     },
     "properties": {
     "date":"1/3/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 166.7348529,-17.99861372 ]
     },
     "properties": {
     "date":"1/4/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 167.4898585,-18.04848655 ]
     },
     "properties": {
     "date":"1/5/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 168.1685921,-17.95994975 ]
     },
     "properties": {
     "date":"1/6/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 168.7671438,-17.77027828 ]
     },
     "properties": {
     "date":"1/7/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 169.3193953,-17.43792518 ]
     },
     "properties": {
     "date":"1/8/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 169.8612128,-17.04414316 ]
     },
     "properties": {
     "date":"1/9/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 170.4140108,-16.56503476 ]
     },
     "properties": {
     "date":"1/10/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 170.6934208,-16.01308411 ]
     },
     "properties": {
     "date":"1/11/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 171.8420641,-15.46330545 ]
     },
     "properties": {
     "date":"1/12/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 173.5270915,-14.93592271 ]
     },
     "properties": {
     "date":"1/13/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 175.1637177,-14.41651746 ]
     },
     "properties": {
     "date":"1/14/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 176.2936879,-13.91980602 ]
     },
     "properties": {
     "date":"1/15/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 177.2510338,-13.41964563 ]
     },
     "properties": {
     "date":"1/16/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.1283721,-12.91773697 ]
     },
     "properties": {
     "date":"1/17/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.7725077,-12.49594802 ]
     },
     "properties": {
     "date":"1/18/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.8619211,-12.29155149 ]
     },
     "properties": {
     "date":"1/19/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.6948071,-12.12560942 ]
     },
     "properties": {
     "date":"1/20/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.4879553,-11.96067225 ]
     },
     "properties": {
     "date":"1/21/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.5208467,-11.8389302 ]
     },
     "properties": {
     "date":"1/22/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 178.9128736,-11.79040856 ]
     },
     "properties": {
     "date":"1/23/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 179.4542202,-11.70158607 ]
     },
     "properties": {
     "date":"1/24/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 180.0802201,-11.52847932 ]
     },
     "properties": {
     "date":"1/25/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 180.698838,-11.29588894 ]
     },
     "properties": {
     "date":"1/26/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 181.2422521,-11.04216289 ]
     },
     "properties": {
     "date":"1/27/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 181.6791388,-10.72901912 ]
     },
     "properties": {
     "date":"1/28/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 182.0622637,-10.27995697 ]
     },
     "properties": {
     "date":"1/29/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 182.4830804,-9.675514768 ]
     },
     "properties": {
     "date":"1/30/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 182.8757153,-9.111705891 ]
     },
     "properties": {
     "date":"1/31/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 183.2299372,-8.544158017 ]
     },
     "properties": {
     "date":"2/1/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 183.4246037,-7.973452509 ]
     },
     "properties": {
     "date":"2/2/2012",
     "id":561100300
     }
   },
   {
     "type": "Feature",
     "geometry": {
        "type": "Point",
        "coordinates":  [ 183.4590627,-7.518217583 ]
     },
     "properties": {
     "date":"2/3/2012",
     "id":561100300
     }
   }
 ]
 }